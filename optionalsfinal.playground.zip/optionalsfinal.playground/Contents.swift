import UIKit


var ages: [Int] = []
ages.sort()
let oldestage = ages.last




